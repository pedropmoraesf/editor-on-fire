EOF Community Edition - Windows (unofficial)
Build date: 2026-10-07
Source: https://github.com/pedropmoraesf/editor-on-fire
Source revision: b9daf69d5993dac002e9093b5c73a0e112284769
Original project: https://github.com/raynebc/editor-on-fire

EN: This is an unofficial, community-modified build of Editor on Fire (EOF),
including DTXMania editing and export functionality. It is not produced or
endorsed by the original EOF developers. It has not undergone complete
regression testing. Please back up your chart projects before use.

PT-BR: Esta e uma compilacao nao oficial do Editor on Fire, com modificacoes
da comunidade, incluindo edicao e exportacao DTXMania. O projeto original
nao endossa esta versao. Nem todas as funcionalidades foram testadas.
Faca backup de seus projetos antes de usar.

INSTALLATION: Extract the full ZIP to a folder where your account can write.
Keep eof.exe alongside the included data files and folders. Do not run it
from inside the ZIP. Some optional audio operations require separately
installed tools such as FFmpeg, LAME, Vorbis Tools, or FluidSynth.

LICENSE: See license.txt and GPL_license.txt, and any other included licenses.
Copyright and licensing information for the original EOF and third-party
components is retained. This package includes no user-specific temporary
projects or temporary audio files.